from tkinter import*
from PIL import Image,ImageTk
from tkinter import ttk
import datetime
from tkinter.ttk import Combobox
import mysql.connector
from tkinter import messagebox


win = Tk()
win.title("ثبت نام دبیرستان")
win.geometry("700x500")


image = ImageTk.PhotoImage(Image.open(r"C:/Users/PaRsAfZaR/Desktop/background.jpg"))
Label(
    master=win,
    image=image
).pack(fill=BOTH,expand=True)


def clear(): 
    en_name.delete("0",END)
    en_lname.delete("0",END)
    en_school.delete("0",END)
    en_ostan.delete("0",END)
    en_city.delete("0",END)
    Lb_state.config(text="")
def savedata():
    
    
    if var.get() == 1:    
       
        data = (en_name.get(),en_lname.get(),en_ostan.get(),en_city.get(),en_school.get(),"متوسطه اول",paye_name.get())
        users_list.insert(END, data)
        sql="INSERT INTO students(name,family,province,city,schools_name,section,grade)VALUES(%s,%s,%s,%s,%s,%s,%s)"
        global mycursor
        mycursor.execute(sql,data)
        myconnection.commit()
        messagebox.showinfo("کاربر ذخیره شد.",f"User{en_name.get()} saved.")
        Lb_state.config(text=f"{mycursor.rowcount}record inserted.")
        Lb_state.after(5000,clear)
    
    else:
    
       
    
        data = (en_name.get(),en_lname.get(),en_ostan.get(),en_city.get(),en_school.get(),"متوسطه دوم",paye_name.get())
        users_list.insert(END, data)
        messagebox.showinfo("کاربر ذخیره شد.",f"User{en_name.get()} saved.")
        sql="INSERT INTO students(name,family,province,city,schools_name,section,grade)VALUES(%s,%s,%s,%s,%s,%s,%s)"
        mycursor.execute(sql,data)
        myconnection.commit()
        Lb_state.config(text=f"{mycursor.rowcount}record inserted.")
        Lb_state.after(5000,clear)



Lb_text = Label(win , text = "خوش آمدید" , font = ("Andalus",17),foreground= ("#3d36a3"))
Lb_text.place(x=7,y=4)

Lb_text = Label(win , text = "Hello" , font = ("Tahoma",15),foreground= ("#3660a3"))
Lb_text.place(x=10,y=40)
def showtime()  :
    t = datetime.datetime.now()
    ti = t.strftime("%X")
    Lb_text.config(text = ti)
    Lb_text.after(1000 , showtime)
showtime() 

Lb_name = Label(win , text = "نام:" , font = ("Book Antiqua",14),foreground= ("#200b2e"))
Lb_name.place(x=10,y=70)
en_name = Entry(win,font = ("Aptos Display",14),foreground=("#0b0929"),width=14,background=("#bfbca3"))
en_name.place(x = 125 ,y =70)

Lb_lname = Label(win , text = "خانوادگی نام:" , font = ("Book Antiqua",14),foreground= ("#200b2e"))
Lb_lname.place(x=10,y=108)
en_lname = Entry(win,font = ("Aptos Display",14),foreground=("#0b0929"),width=14,background=("#bfbca3"))
en_lname.place(x = 125 ,y =108)

Lb_ostan = Label(win , text = "استان نام:" , font = ("Book Antiqua",14),foreground= ("#200b2e"))
Lb_ostan.place(x=10,y=145)
en_ostan = Entry(win,font = ("Aptos Display",14),foreground=("#0b0929"),width=14,background=("#bfbca3"))
en_ostan.place(x = 125 ,y =145)

Lb_city = Label(win , text = "شهر نام:" , font = ("Book Antiqua",14),foreground= ("#200b2e"))
Lb_city.place(x=10,y=180)
en_city = Entry(win,font = ("Aptos Display",14),foreground=("#0b0929"),width=14,background=("#bfbca3"))
en_city.place(x = 125 ,y =180)

Lb_school = Label(win , text = "مدرسه نام:" , font = ("Book Antiqua",14),foreground= ("#200b2e"))
Lb_school.place(x=10,y=220)
en_school = Entry(win,font = ("Aptos Display",14),foreground=("#0b0929"),width=14,background=("#bfbca3"))
en_school.place(x = 125 ,y =220)

Lb_radio = Label(win , text = "تحصیلی مقطع:" , font = ("Book Antiqua",14),foreground= ("#200b2e"))
Lb_radio.place(x=10,y=255)

var =IntVar()
r2 = Radiobutton(win , text = "متوسطه اول" , variable=var,value=1, font = ("Tahoma 12"),foreground=("#200b2e"))
r2.place(x = 7, y =  290)
r3 = Radiobutton(win , text = "متوسطه دوم" , variable=var,value=2, font = ("Tahoma 12"),foreground=("#200b2e"))
r3.place(x =130 , y =  290)

lb_paye = Label(win , text = "تحصیلی پایه:" , font = ("Book Antiqua",14),foreground= ("#200b2e"))
lb_paye.place(x=10,y=330)
paye_name = StringVar()
paye_list = ["هفتم" , "هشتم","نهم","دهم","یازدهم","دوازدهم"]
combo_paye= Combobox(win , textvariable=paye_name  , values=paye_list, font=("Aptos Display",14),width=10,foreground=("#0b0929"),background=("#bfbca3"))
combo_paye.place(x =125 , y = 330)
combo_paye["state"]="readonly"

def deletesel():
    sel = users_list.curselection()
    users_list.delete(sel)
def daleteall():
     users_list.delete("0" , END)

bt_delsel = Button(win , text="حذف",font = ("Tahoma", 10),width=9, background="#398064" , foreground="black", command= deletesel)
bt_delsel.place(x = 616 , y = 270)

bt_delall =  Button(win , text="حذف همه",font = ("Tahoma", 10),width=9,background="#398064" , foreground="black" , command=daleteall)
bt_delall.place(x = 540 , y = 270)


bt_save = Button(win , text = "save", font = ("Aptos Display",10),background = ("#376636"),foreground=("white"), width= 13,command=savedata)
bt_save.place(x=10, y = 460)


bt_exit = Button(win , text = "exit", font = ("Aptos Display",10),background = ("#611208"),foreground=("white"), width= 13,command=win.quit)
bt_exit.place(x=125 , y = 460)


Lb_info = Label(win , text = " شما مشخصات:" , font = ("Bell MT",15),foreground= ("#3d3980"))
Lb_info.place(x=290,y=120)
users_list = Listbox(win,width=57 , height=7 , font=("Tahoma",9), selectbackground="#398064",background="#bfbca3")
users_list.place(x=290,y=150)


def donothing():
   filewin = Toplevel(win)
   button = Button(filewin, text="Do nothing button")
   button.pack()
   
menubar = Menu(win)
filemenu = Menu(menubar, tearoff=0)
filemenu.add_command(label="New", command=donothing)
filemenu.add_command(label="Save", command=donothing)
filemenu.add_command(label="Close", command=donothing)

filemenu.add_separator()
filemenu.add_command(label="Exit", command=win.quit)
menubar.add_cascade(label="File", menu=filemenu)
editmenu = Menu(menubar, tearoff=0)
editmenu.add_command(label="Undo", command=donothing)
editmenu.add_separator()
editmenu.add_command(label="Delete", command=donothing)
menubar.add_cascade(label="Edit", menu=editmenu)
helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label="Help Index", command=donothing)
menubar.add_cascade(label="Help", menu=helpmenu)

win.config(menu=menubar)

def createconnection():
    try:
        global myconnection
       
        myconnection = mysql.connector.connect(
    host = "localhost",
    user = "root",
    password = "",
    database = "myapp"
)
        global mycursor
        mycursor = myconnection.cursor()

    except:
            Lb_state.config(text = "خطا در برقراری ارتباط.")
    else:
        Lb_state.config(text = "ارتباط برقرار شد.")

Lb_state = Label(win , text = "ready." , font = ("Tahoma",10),foreground= ("black"))
Lb_state.place(x=10,y=430)

bt_connect = Button(win , text = "ذخیره شدن در لیست", font = ("Tahoma",10),background = ("#799400"),foreground=("black"), width= 19 , command=createconnection)
bt_connect.place(x=540 , y = 310)

def mytabale():
    global myconnection   
    myconnection = mysql.connector.connect(
    host = "localhost",
    user = "root",
    password = "",
    database = "myapp"
)
    global mycursor
    mycursor = myconnection.cursor()
    try:
        mycursor.execute("CREATE TABLE students (id INT AUTO_INCREMENT PRIMARY KEY , name VARCHAR (25), family VARCHAR(25), province VARCHAR(30),city VARCHAR(30),schools_name VARCHAR(30),section VARCHAR(20),grade VARCHAR(20))")
    except:
        Lb_state.config(text = "جدول ثبت نام وجود دارد")
    else:
        Lb_state.config(text = "جدول ثبت نام ساخته شد")
bt_createtable = Button(win, text="ساخت جدول" , font= ("Tahoma",9) , background="#799400", foreground="black",width=19, command=mytabale)
bt_createtable.place(x =540, y = 345)


def showusers():
    mycursor.execute("SELECT * FROM  students")
    users_list.delete("0",END)
    if mycursor:
        for x in mycursor:
            users_list.insert(END,x)
    else:
        Lb_state.config(text= "کاربری وجود ندارد")
bt_showusers = Button(win, text="نمایش ثبت نام مدارس" , font= ("Tahoma", 9 ) , background="#799400", foreground="black",width=19 , command=showusers)
bt_showusers.place(x = 540, y = 375)


def searchusers():
    try:
        mycursor.execute("SELECT*FROM students WHERE name LIKE %s",("%" + en_search.get() + "%",))
        if mycursor:
            search_list.delete("0",END)
            for x in mycursor:
                search_list.insert(END, x)
    except:
        Lb_state.config(text="کاربری پیدا نشد!")


Lb_search = Label(win , text = "جستجو ی نام:" , font = ("Tahoma",11),foreground= ("black"))
Lb_search.place(x=290,y=10)


en_search = Entry(win , font = ("Tahoma",13),foreground= ("black"),background=("#bfbca3"))
en_search.place(x=390,y=10)

bt_search = Button(win,text="جستجو",command=searchusers)
bt_search.place(x=585,y=10)

search_list = Listbox(win,width=57 , height=5 , font=("Tahoma",9), selectbackground="#398064",background="#bfbca3")
search_list.place(x=290,y=40)







win.mainloop()