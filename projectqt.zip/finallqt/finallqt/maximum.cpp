#include "maximum.h"
#include "ui_maximum.h"
#include"finallqt.h"
maximum::maximum(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::maximum)
{
    ui->setupUi(this);
}

maximum::~maximum()
{
    delete ui;
}

void maximum::on_calcumaxButton_clicked()
{
    int a=ui->max1lineEdit->text().toInt();
    int b=ui->max2lineEdit->text().toInt();
    int c=ui->max3lineEdit->text().toInt();
    int max=a;
    if(max<b)
        max=b;
    if(max<c)
        max=c;
    ui->maxlabel->setText(QString::number(max));
}


void maximum::on_back12Button_clicked()
{
    finallqt *f12 = new finallqt;
    f12->show();
    hide();
}

