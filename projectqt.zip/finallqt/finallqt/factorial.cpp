#include "factorial.h"
#include "ui_factorial.h"
#include"finallqt.h"
factorial::factorial(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::factorial)
{
    ui->setupUi(this);
}

factorial::~factorial()
{
    delete ui;
}

void factorial::on_factButton_clicked()
{
    int n=ui->factlineEdit->text().toInt();
    int i=1,f=1;
    while(i<=n)
    {   f*=i;
        i++;}
    ui->factlabel->setText(QString::number(f));
}


void factorial::on_back7Button_clicked()
{
    finallqt *f7 = new finallqt;
    f7->show();
    hide();
}

