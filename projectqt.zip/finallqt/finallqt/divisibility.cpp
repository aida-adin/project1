#include "divisibility.h"
#include "ui_divisibility.h"
#include"finallqt.h"
divisibility::divisibility(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::divisibility)
{
    ui->setupUi(this);
}

divisibility::~divisibility()
{
    delete ui;
}

void divisibility::on_divButton_clicked()
{
    int n1=ui->div1lineEdit->text().toInt();
    int n2=ui->div2lineEdit->text().toInt();
    if(n1%n2==0)
        ui->divtextEdit->setText("The first number is divisible by the second number\n");
    else if(n2%n1==0)
        ui->divtextEdit->setText("The second number is divisible by the first number\n");
    else if(n1%n2!=0)
        ui->divtextEdit->setText("The first number is not divisible by the second number\n");
    else
        ui->divtextEdit->setText("The second number is not divisible by the first number\n");
}


void divisibility::on_back10Button_clicked()
{
    finallqt *f10 = new finallqt;
    f10->show();
    hide();
}

