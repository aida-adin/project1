#ifndef DIVISIBILITY_H
#define DIVISIBILITY_H

#include <QMainWindow>

namespace Ui {
class divisibility;
}

class divisibility : public QMainWindow
{
    Q_OBJECT

public:
    explicit divisibility(QWidget *parent = nullptr);
    ~divisibility();

private slots:
    void on_divButton_clicked();

    void on_back10Button_clicked();

private:
    Ui::divisibility *ui;
};

#endif // DIVISIBILITY_H
