#include "absolute.h"
#include "ui_absolute.h"
#include"finallqt.h"

absolute::absolute(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::absolute)
{
    ui->setupUi(this);
}

absolute::~absolute()
{
    delete ui;
}

void absolute::on_calcuabsButton_clicked()
{
    int n=ui->abslineEdit->text().toInt();
    int res;
    if(n<0)
    {res=n*-1;
        ui->abslabel->setText(QString::number(res));}
    else
        ui->abslabel->setText(QString::number(n));
}


void absolute::on_pushButton_clicked()
{
    finallqt *f = new finallqt;
    f->show();
    hide();
}

