#include "numberofdigits.h"
#include "ui_numberofdigits.h"
#include"finallqt.h"
numberofdigits::numberofdigits(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::numberofdigits)
{
    ui->setupUi(this);
}

numberofdigits::~numberofdigits()
{
    delete ui;
}

void numberofdigits::on_numberdigitsButton_clicked()
{
    int n=ui->numberdigitslineEdit->text().toInt();
    int c=0;
    while(n!=0)
    {   c++;
        n/=10;}
    ui->numberdigitslabel->setText(QString::number(c));
}


void numberofdigits::on_back11Button_clicked()
{
    finallqt *f11 = new finallqt;
    f11->show();
    hide();
}

