#ifndef AREA_H
#define AREA_H

#include <QMainWindow>

namespace Ui {
class Area;
}

class Area : public QMainWindow
{
    Q_OBJECT

public:
    explicit Area(QWidget *parent = nullptr);
    ~Area();

private slots:
    void on_areaButton_clicked();

    void on_back5Button_clicked();

private:
    Ui::Area *ui;
};

#endif // AREA_H
