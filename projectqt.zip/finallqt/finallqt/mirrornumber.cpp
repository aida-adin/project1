#include "mirrornumber.h"
#include "ui_mirrornumber.h"
#include"finallqt.h"
mirrornumber::mirrornumber(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::mirrornumber)
{
    ui->setupUi(this);
}

mirrornumber::~mirrornumber()
{
    delete ui;
}

void mirrornumber::on_calcumirrorButton_clicked()
{
    int n=ui->mirrorlineEdit->text().toInt();
    int s=0,r,x;
    x=n;
    QString res;
    while(n!=0)
    {   r=n%10;
        s=s*10+r;
        n/=10;}
    if(x==s)
        res="mirror number";
    else
        res="not mirror number";
    ui->mirrorlabel->setText(res);
}


void mirrornumber::on_back15Button_clicked()
{
    finallqt *f15 = new finallqt;
    f15->show();
    hide();
}

