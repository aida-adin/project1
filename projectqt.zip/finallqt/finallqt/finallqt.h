#ifndef FINALLQT_H
#define FINALLQT_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class finallqt;
}
QT_END_NAMESPACE

class finallqt : public QMainWindow
{
    Q_OBJECT

public:
    finallqt(QWidget *parent = nullptr);
    ~finallqt();

private slots:
    void on_absButton_clicked();

    void on_evoButton_clicked();

    void on_salaryButton_clicked();

    void on_triangleButton_clicked();

    void on_areaButton_clicked();

    void on_sumButton_clicked();

    void on_factButton_clicked();

    void on_inverseButton_clicked();

    void on_perfectButton_clicked();

    void on_divButton_clicked();

    void on_numberButton_clicked();

    void on_maximumButton_clicked();

    void on_inflactionButton_clicked();

    void on_primeButton_clicked();

    void on_mirrorButton_clicked();

private:
    Ui::finallqt *ui;
};
#endif // FINALLQT_H
