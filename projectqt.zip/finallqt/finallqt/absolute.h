#ifndef ABSOLUTE_H
#define ABSOLUTE_H

#include <QMainWindow>

namespace Ui {
class absolute;
}

class absolute : public QMainWindow
{
    Q_OBJECT

public:
    explicit absolute(QWidget *parent = nullptr);
    ~absolute();

private slots:
    void on_calcuabsButton_clicked();

    void on_pushButton_clicked();

private:
    Ui::absolute *ui;
};

#endif // ABSOLUTE_H
