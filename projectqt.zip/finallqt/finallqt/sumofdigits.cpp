#include "sumofdigits.h"
#include "ui_sumofdigits.h"
#include "finallqt.h"
sumofdigits::sumofdigits(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::sumofdigits)
{
    ui->setupUi(this);
}

sumofdigits::~sumofdigits()
{
    delete ui;
}

void sumofdigits::on_sumButton_clicked()
{
    int x=ui->sumlineEdit->text().toInt();
    int n=x,r,s=0;
    while(n!=0)
    {r=n%10;
        n/=10;
        s+=r;}
    ui->sumlabel->setText(QString::number(s));
}


void sumofdigits::on_back6Button_clicked()
{
    finallqt *f6 = new finallqt;
    f6->show();
    hide();
}

