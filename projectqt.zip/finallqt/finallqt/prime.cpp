#include "prime.h"
#include "ui_prime.h"
#include"finallqt.h"
prime::prime(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::prime)
{
    ui->setupUi(this);
}

prime::~prime()
{
    delete ui;
}

void prime::on_calcuprimeButton_clicked()
{
     int n=ui->primelineEdit->text().toInt();
    QString q;
    int i,p=0;
     for(i=1;i<=n;i++)
    {if(n%i==0)
        p++;}
     if(p==2)
         q="prime";
     else
         q="not prime";
     ui->primelabel->setText(q);
}


void prime::on_back14Button_clicked()
{
    finallqt *f14 = new finallqt;
    f14->show();
    hide();
}

