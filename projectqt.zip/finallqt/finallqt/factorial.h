#ifndef FACTORIAL_H
#define FACTORIAL_H

#include <QMainWindow>

namespace Ui {
class factorial;
}

class factorial : public QMainWindow
{
    Q_OBJECT

public:
    explicit factorial(QWidget *parent = nullptr);
    ~factorial();

private slots:
    void on_factButton_clicked();

    void on_back7Button_clicked();

private:
    Ui::factorial *ui;
};

#endif // FACTORIAL_H
