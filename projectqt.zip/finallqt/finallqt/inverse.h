#ifndef INVERSE_H
#define INVERSE_H

#include <QMainWindow>

namespace Ui {
class inverse;
}

class inverse : public QMainWindow
{
    Q_OBJECT

public:
    explicit inverse(QWidget *parent = nullptr);
    ~inverse();

private slots:
    void on_inverseButton_clicked();

    void on_back8Button_clicked();

private:
    Ui::inverse *ui;
};

#endif // INVERSE_H
