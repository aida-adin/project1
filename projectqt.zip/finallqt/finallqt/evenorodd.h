#ifndef EVENORODD_H
#define EVENORODD_H

#include <QMainWindow>

namespace Ui {
class evenorodd;
}

class evenorodd : public QMainWindow
{
    Q_OBJECT

public:
    explicit evenorodd(QWidget *parent = nullptr);
    ~evenorodd();

private slots:
    void on_calcuevenoroddButton_clicked();

    void on_back2Button_clicked();

private:
    Ui::evenorodd *ui;
};

#endif // EVENORODD_H
