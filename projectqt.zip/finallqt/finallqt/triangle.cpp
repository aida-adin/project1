#include "triangle.h"
#include "ui_triangle.h"
#include"finallqt.h"
triangle::triangle(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::triangle)
{
    ui->setupUi(this);
}

triangle::~triangle()
{
    delete ui;
}

void triangle::on_calcutriangleButton_clicked()
{
    int a=ui->side1lineEdit->text().toInt();
    int b=ui->side2lineEdit->text().toInt();
    int c=ui->side3lineEdit->text().toInt();
    QString res;
    if(a+b>c&&a+c>b&&b+c>a)
        res="triangle";
    else
        res="no triangle";
    ui->trianglelabel->setText(res);
}


void triangle::on_back4Button_clicked()
{
    finallqt *f4 = new finallqt;
    f4->show();
    hide();
}

