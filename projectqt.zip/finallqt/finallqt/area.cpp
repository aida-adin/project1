#include "area.h"
#include "ui_area.h"
#include"finallqt.h"
Area::Area(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Area)
{
    ui->setupUi(this);
}

Area::~Area()
{
    delete ui;
}

void Area::on_areaButton_clicked()
{
    int r=ui->radiuslineEdit->text().toInt();
    float area=r*r*3.14;
    ui->arealabel->setText(QString::number(area));
}


void Area::on_back5Button_clicked()
{
    finallqt *f5 = new finallqt;
    f5->show();
    hide();
}

