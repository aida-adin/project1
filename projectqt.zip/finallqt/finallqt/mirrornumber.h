#ifndef MIRRORNUMBER_H
#define MIRRORNUMBER_H

#include <QMainWindow>

namespace Ui {
class mirrornumber;
}

class mirrornumber : public QMainWindow
{
    Q_OBJECT

public:
    explicit mirrornumber(QWidget *parent = nullptr);
    ~mirrornumber();

private slots:
    void on_calcumirrorButton_clicked();

    void on_back15Button_clicked();

private:
    Ui::mirrornumber *ui;
};

#endif // MIRRORNUMBER_H
