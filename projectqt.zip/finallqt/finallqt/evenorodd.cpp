#include "evenorodd.h"
#include "ui_evenorodd.h"
#include"finallqt.h"
evenorodd::evenorodd(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::evenorodd)
{
    ui->setupUi(this);
}

evenorodd::~evenorodd()
{
    delete ui;
}

void evenorodd::on_calcuevenoroddButton_clicked()
{
    int n=ui->evenoroddlineEdit->text().toInt();
    QString res;
    if(n%2==0)
        res="Even";
    else
        res="odd";
    ui->label_3->setText(res);
}


void evenorodd::on_back2Button_clicked()
{
    finallqt *f2 = new finallqt;
    f2->show();
    hide();
}

