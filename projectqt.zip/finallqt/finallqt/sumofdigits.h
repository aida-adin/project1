#ifndef SUMOFDIGITS_H
#define SUMOFDIGITS_H

#include <QMainWindow>

namespace Ui {
class sumofdigits;
}

class sumofdigits : public QMainWindow
{
    Q_OBJECT

public:
    explicit sumofdigits(QWidget *parent = nullptr);
    ~sumofdigits();

private slots:
    void on_sumButton_clicked();

    void on_back6Button_clicked();

private:
    Ui::sumofdigits *ui;
};

#endif // SUMOFDIGITS_H
