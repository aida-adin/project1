#ifndef SALARY_H
#define SALARY_H

#include <QMainWindow>

namespace Ui {
class salary;
}

class salary : public QMainWindow
{
    Q_OBJECT

public:
    explicit salary(QWidget *parent = nullptr);
    ~salary();

private slots:
    void on_calcusalaryButton_clicked();

    void on_back3Button_clicked();

private:
    Ui::salary *ui;
};

#endif // SALARY_H
