#include "salary.h"
#include "ui_salary.h"
#include"finallqt.h"

salary::salary(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::salary)
{
    ui->setupUi(this);
}

salary::~salary()
{
    delete ui;
}

void salary::on_calcusalaryButton_clicked()
{
    int time=ui->workhourslineEdit->text().toInt();
    int rate=ui->hourlyratelineEdit->text().toInt();
    int res=time*rate;
    ui->salarylabel->setText(QString::number(res));
}


void salary::on_back3Button_clicked()
{
    finallqt *f3 = new finallqt;
    f3->show();
    hide();
}

