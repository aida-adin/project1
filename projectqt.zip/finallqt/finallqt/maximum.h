#ifndef MAXIMUM_H
#define MAXIMUM_H

#include <QMainWindow>

namespace Ui {
class maximum;
}

class maximum : public QMainWindow
{
    Q_OBJECT

public:
    explicit maximum(QWidget *parent = nullptr);
    ~maximum();

private slots:
    void on_calcumaxButton_clicked();

    void on_back12Button_clicked();

private:
    Ui::maximum *ui;
};

#endif // MAXIMUM_H
