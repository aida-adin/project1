#include "finallqt.h"
#include "ui_finallqt.h"
#include"absolute.h"
#include"evenorodd.h"
#include"salary.h"
#include"triangle.h"
#include"area.h"
#include"sumofdigits.h"
#include"factorial.h"
#include"inverse.h"
#include"perfect.h"
#include"divisibility.h"
#include"numberofdigits.h"
#include"maximum.h"
#include"inflation.h"
#include"prime.h"
#include"mirrornumber.h"

finallqt::finallqt(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::finallqt)
{
    ui->setupUi(this);
}

finallqt::~finallqt()
{
    delete ui;
}

void finallqt::on_absButton_clicked()
{
    absolute *abs = new absolute;
    abs->show();
    hide();
}


void finallqt::on_evoButton_clicked()
{
    evenorodd *evo = new evenorodd;
    evo->show();
    hide();
}


void finallqt::on_salaryButton_clicked()
{
    salary *sal = new salary;
    sal->show();
    hide();
}


void finallqt::on_triangleButton_clicked()
{
    triangle *tri = new triangle;
    tri->show();
    hide();
}



void finallqt::on_areaButton_clicked()
{
    Area *ar = new Area;
    ar->show();
    hide();
}


void finallqt::on_sumButton_clicked()
{
    sumofdigits *sum = new sumofdigits;
    sum->show();
    hide();
}


void finallqt::on_factButton_clicked()
{
    factorial *fact = new factorial;
    fact->show();
    hide();
}


void finallqt::on_inverseButton_clicked()
{
    inverse *inv = new inverse;
    inv->show();
    hide();
}


void finallqt::on_perfectButton_clicked()
{
    perfect *prf = new perfect;
    prf->show();
    hide();
}


void finallqt::on_divButton_clicked()
{
    divisibility *dv = new divisibility;
    dv->show();
    hide();
}


void finallqt::on_numberButton_clicked()
{
    numberofdigits *nod = new numberofdigits;
    nod->show();
    hide();
}


void finallqt::on_maximumButton_clicked()
{
    maximum *max = new maximum;
    max->show();
    hide();
}


void finallqt::on_inflactionButton_clicked()
{
    Inflation *inf = new Inflation;
    inf->show();
    hide();
}


void finallqt::on_primeButton_clicked()
{
    prime *pri = new prime;
    pri->show();
    hide();
}


void finallqt::on_mirrorButton_clicked()
{
    mirrornumber *mirn = new mirrornumber;
    mirn->show();
    hide();
}

