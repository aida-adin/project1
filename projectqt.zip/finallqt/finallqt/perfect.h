#ifndef PERFECT_H
#define PERFECT_H

#include <QMainWindow>

namespace Ui {
class perfect;
}

class perfect : public QMainWindow
{
    Q_OBJECT

public:
    explicit perfect(QWidget *parent = nullptr);
    ~perfect();

private slots:
    void on_perfectButton_clicked();

    void on_pushButton_clicked();

private:
    Ui::perfect *ui;
};

#endif // PERFECT_H
