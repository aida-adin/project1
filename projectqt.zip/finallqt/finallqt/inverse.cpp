#include "inverse.h"
#include "ui_inverse.h"
#include"finallqt.h"
inverse::inverse(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::inverse)
{
    ui->setupUi(this);
}

inverse::~inverse()
{
    delete ui;
}

void inverse::on_inverseButton_clicked()
{
    int n=ui->inverselineEdit->text().toInt();
    int i=0,r;
    while(n!=0)
    {   r=n%10;
        n/=10;
        i=(i*10)+r;}
    ui->inverselabel->setText(QString::number(i));
}


void inverse::on_back8Button_clicked()
{
    finallqt *f8 = new finallqt;
    f8->show();
    hide();
}

