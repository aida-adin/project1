#include "inflation.h"
#include "ui_inflation.h"
#include"finallqt.h"

Inflation::Inflation(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Inflation)
{
    ui->setupUi(this);
}

Inflation::~Inflation()
{
    delete ui;
}

void Inflation::on_calcuinflactionButton_clicked()
{
    float ny=ui->inflaction1lineEdit->text().toFloat();
    float py=ui->inflaction2lineEdit->text().toFloat();
    float p;
    p=((ny-py)/py)*100;
    ui->inflactionlabel->setText(QString::number(p,'f',2));
}


void Inflation::on_back13Button_clicked()
{
    finallqt *f13 = new finallqt;
    f13->show();
    hide();
}

