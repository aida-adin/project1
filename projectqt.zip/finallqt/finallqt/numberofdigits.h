#ifndef NUMBEROFDIGITS_H
#define NUMBEROFDIGITS_H

#include <QMainWindow>

namespace Ui {
class numberofdigits;
}

class numberofdigits : public QMainWindow
{
    Q_OBJECT

public:
    explicit numberofdigits(QWidget *parent = nullptr);
    ~numberofdigits();

private slots:
    void on_numberdigitsButton_clicked();

    void on_back11Button_clicked();

private:
    Ui::numberofdigits *ui;
};

#endif // NUMBEROFDIGITS_H
