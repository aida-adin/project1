#include "perfect.h"
#include "ui_perfect.h"
#include"finallqt.h"
perfect::perfect(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::perfect)
{
    ui->setupUi(this);
}

perfect::~perfect()
{
    delete ui;
}

void perfect::on_perfectButton_clicked()
{
    int n=ui->perfectlineEdit->text().toInt();
    int s=0,i=1;
    QString perf;
    while(i<n)
    {   if(n%i==0)
        s+=i;
        i++;}
    if(s==n)
        perf="perfect";
    else
        perf="not perfect";
    ui->perfectlabel->setText(perf);

}


void perfect::on_pushButton_clicked()
{
    finallqt *f9 = new finallqt;
    f9->show();
    hide();
}

