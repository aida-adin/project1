#ifndef INFLATION_H
#define INFLATION_H

#include <QMainWindow>

namespace Ui {
class Inflation;
}

class Inflation : public QMainWindow
{
    Q_OBJECT

public:
    explicit Inflation(QWidget *parent = nullptr);
    ~Inflation();

private slots:
    void on_calcuinflactionButton_clicked();

    void on_back13Button_clicked();

private:
    Ui::Inflation *ui;
};

#endif // INFLATION_H
