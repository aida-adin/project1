#ifndef PRIME_H
#define PRIME_H

#include <QMainWindow>

namespace Ui {
class prime;
}

class prime : public QMainWindow
{
    Q_OBJECT

public:
    explicit prime(QWidget *parent = nullptr);
    ~prime();

private slots:
    void on_calcuprimeButton_clicked();

    void on_back14Button_clicked();

private:
    Ui::prime *ui;
};

#endif // PRIME_H
